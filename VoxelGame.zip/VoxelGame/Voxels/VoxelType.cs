﻿namespace Voxels
{
    public enum VoxelType : ushort
    {
        AIR = 0,
        DIRT,
        GRASS,
        STONE,
    }
}
