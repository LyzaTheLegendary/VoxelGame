﻿namespace Voxels
{
    public enum VoxelType : ushort
    {
        AIR,
        DIRT,
        GRASS,
        STONE
    }
}
