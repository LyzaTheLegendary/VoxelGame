﻿using System.Collections.Concurrent;

namespace Content.Universe
{
    public enum WorldType: byte
    {
        EARTH,
    }
    public class World
    {
        ConcurrentDictionary<(int, int, int), Chunk> chunks = new ConcurrentDictionary<(int, int, int), Chunk>();

        public string WorldName { get; private set; }
        public WorldType Type { get; private set; }
        public World(string name, WorldType type = WorldType.EARTH)
        {
            WorldName = name;
            Type = type;
        }

        public Chunk GetChunk(int x, int y, int z)
        {
            if (!chunks.TryGetValue((x, y, z), out Chunk chunk))
            {
                chunk = new Chunk(x, y, z);
                chunks.TryAdd((x, y, z), chunk);
            }
            return chunk;
        }
    }
}
