﻿using Graphics.GpuMemory;
using OpenTK.Mathematics;
using Voxels;

namespace Content.Universe
{
    public class Chunk
    {
        public GpuShaderStorageBuffer<VoxelType> Buffer { get; init; }
        public Vector3 Position { get; init; }
        public Chunk()
        {
            
        }
    }
}
