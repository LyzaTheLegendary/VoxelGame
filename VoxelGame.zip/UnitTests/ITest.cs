﻿namespace UnitTests
{
    public interface ITest
    {
        public void Run();
    }
}
